// Interface
interface FreteStrategy {
    calcular(valorPedido: number): number;
}

// Estratégias Concretas
class FreteComum implements FreteStrategy {
    public calcular(valorPedido: number): number {
        return valorPedido * 0.05;  // 5% do  valor (mais barato, mais lento)
    }
}

class FreteExpresso implements FreteStrategy {
    public calcular(valorPedido: number): number {
        return valorPedido * 0.10; // 10% do valor (mais caro, mais rápido)
    }
}

class FreteGratis implements FreteStrategy {
    public calcular(valorPedido: number): number {
        // Regra de negócio: só é grátis se for acima de 100, senão cobra taxa fixa
        if (valorPedido > 100) {
            return 0;
        }
        return 20; 
    }
}

// Contexto
class Pedido {
    private freteStrategy: FreteStrategy;
    private valor: number;

    constructor(valor: number, strategyInicial: FreteStrategy) {
        this.valor = valor;
        this.freteStrategy = strategyInicial;
    }

    public setStrategy(strategy: FreteStrategy): void {
        this.freteStrategy = strategy;
    }

    public calcularTotalComFrete(): void {
        const custoFrete = this.freteStrategy.calcular(this.valor);
        const total = this.valor + custoFrete;
        
        console.log(`
            Valor do Pedido: R$ ${this.valor}
            Tipo de Frete: ${this.freteStrategy.constructor.name}
            Custo do Frete: R$ ${custoFrete}
            TOTAL: R$ ${total}
        `);
    }
}

// --- Execução ---

// Criamos um pedido de R$ 200 com frete comum inicialmente
const meuPedido = new Pedido(200, new FreteComum());
meuPedido.calcularTotalComFrete();

// O cliente mudou de ideia e quer expresso
meuPedido.setStrategy(new FreteExpresso());
meuPedido.calcularTotalComFrete();

// O sistema detectou uma promoção e aplicou frete grátis
meuPedido.setStrategy(new FreteGratis());
meuPedido.calcularTotalComFrete();